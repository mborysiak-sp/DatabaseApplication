CREATE TRIGGER delete_user 
ON [user]
INSTEAD OF DELETE
AS
BEGIN
DELETE FROM logging WHERE logging.id_user IN (SELECT deleted.id_user FROM deleted);
DELETE FROM [user] WHERE id_user IN (SELECT deleted.id_user FROM deleted);
END
go


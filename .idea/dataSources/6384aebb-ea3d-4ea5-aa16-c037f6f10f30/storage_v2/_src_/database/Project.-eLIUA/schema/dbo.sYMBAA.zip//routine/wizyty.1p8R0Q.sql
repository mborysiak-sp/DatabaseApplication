CREATE PROCEDURE wizyty AS
SELECT wizyta.id_pacjent, pacjent.nazwisko as pacjent_nazwisko, wizyta.data_wizyty, lekarz.nazwisko as lekarz_nazwisko, lekarz.specjalizacja as lekarz_specjalizacja , pokoj.id_pokoj
FROM wizyta INNER JOIN pacjent
                       on wizyta.id_pacjent = pacjent.id_pacjent
            INNER JOIN lekarz
                       on wizyta.id_lekarz = lekarz.id_lekarz
            INNER JOIN pokoj
                       on wizyta.id_pokoj = pokoj.id_pokoj;
go

